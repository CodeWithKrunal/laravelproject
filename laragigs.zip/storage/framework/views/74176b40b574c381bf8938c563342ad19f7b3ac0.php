<?php if(session()->has('message')): ?>
    <p x-data="{show: true}"
    x-show="show"
    x-init="setTimeout(() => show = false, 3000)" class="fixed top-0 left-1/3 text-center bg-green-700 text-white px-48 py-3">
    <?php echo e(session('message')); ?>

    </p>
<?php endif; ?><?php /**PATH I:\xampp\htdocs\laragigs\resources\views/components/flash-message.blade.php ENDPATH**/ ?>