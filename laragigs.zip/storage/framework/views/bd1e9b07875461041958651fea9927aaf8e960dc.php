<?php foreach($attributes->onlyProps(['listing']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['listing']); ?>
<?php foreach (array_filter((['listing']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php if (isset($component)) { $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Card::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Card::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="flex">
        <img
            class="hidden w-48 mr-6 md:block"
            src="<?php echo e($listing->logo ? asset('public/storage/'. $listing->logo) : asset('public/images/no-image.png')); ?>"
            alt=""
        />
        <div>
            <h3 class="text-2xl">
                <a href="<?php echo e(Request::url()); ?>/show/<?php echo e($listing['id']); ?>"><?php echo e($listing['title']); ?></a>



            </h3>
            <div class="text-xl font-bold mb-4"><?php echo e($listing['company']); ?></div>
           <?php if (isset($component)) { $__componentOriginal29a46010d857f546f72f259219a0c99cd861cb27 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Listingtags::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('listingtags'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Listingtags::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tagsCsv' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($listing['tags'])]); ?>
            <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal29a46010d857f546f72f259219a0c99cd861cb27)): ?>
<?php $component = $__componentOriginal29a46010d857f546f72f259219a0c99cd861cb27; ?>
<?php unset($__componentOriginal29a46010d857f546f72f259219a0c99cd861cb27); ?>
<?php endif; ?>
            <div class="text-lg mt-4">
                <i class="fa-solid fa-location-dot"></i>
                <?php echo e($listing['location']); ?>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8)): ?>
<?php $component = $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8; ?>
<?php unset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8); ?>
<?php endif; ?>
<?php /**PATH I:\xampp\htdocs\laragigs\resources\views/components/listingcard.blade.php ENDPATH**/ ?>