<?php $__env->startSection('content'); ?>
<?php /* ?>
<h2>
   Title: {{$listing['title']}}
</h2>
<h3>Comapany: {{$listing['company']}}</h3>
<h3>Location: {{$listing['location']}}</h3>
<h3>Website: {{$listing['website']}}</h3>
<h3>Tags: {{$listing['tags']}}</h3>

<p>
    Description: {{$listing['description']}}
</p>
<?php */ ?>

<a href="<?php echo e(url('/')); ?>" class="inline-block text-black ml-4 mb-4"
                ><i class="fa-solid fa-arrow-left"></i> Back
            </a>
            <div class="mx-4">
                <?php if (isset($component)) { $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Card::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Card::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <div
                        class="flex flex-col items-center justify-center text-center"
                    >
                        <img
                            class="w-48 mr-6 mb-6"
                            src="<?php echo e($listing->logo ? asset('public/storage/' . $listing->logo ) : asset('public/images/no-image.png')); ?>"
                            alt=""
                        />



                        <h3 class="text-2xl mb-2"><?php echo e($listing['title']); ?></h3>
                        <div class="text-xl font-bold mb-4"><?php echo e($listing['company']); ?></div>

                        <?php if (isset($component)) { $__componentOriginal29a46010d857f546f72f259219a0c99cd861cb27 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Listingtags::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('listingtags'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Listingtags::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tagsCsv' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($listing['tags'])]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal29a46010d857f546f72f259219a0c99cd861cb27)): ?>
<?php $component = $__componentOriginal29a46010d857f546f72f259219a0c99cd861cb27; ?>
<?php unset($__componentOriginal29a46010d857f546f72f259219a0c99cd861cb27); ?>
<?php endif; ?>

                        <div class="text-lg my-4">
                            <i class="fa-solid fa-location-dot"></i> <?php echo e($listing['location']); ?>

                        </div>
                        <div class="border border-gray-200 w-full mb-6"></div>
                        <div>
                            <h3 class="text-3xl font-bold mb-4">
                                Job Description
                            </h3>
                            <div class="text-lg space-y-6">
                                <p>
                                   <?php echo e($listing['description']); ?>

                                </p>


                                <a
                                    href="mailto:<?php echo e($listing['email']); ?>"
                                    class="block bg-laravel text-white mt-6 py-2 rounded-xl hover:opacity-80"
                                    ><i class="fa-solid fa-envelope"></i>
                                    Contact Employer</a
                                >

                                <a
                                    href="<?php echo e($listing['website']); ?>"
                                    target="_blank"
                                    class="block bg-black text-white py-2 rounded-xl hover:opacity-80"
                                    ><i class="fa-solid fa-globe"></i> Visit
                                    Website</a
                                >
                            </div>

                        </div>
                    </div>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8)): ?>
<?php $component = $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8; ?>
<?php unset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Card::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Card::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mt-4 p-2 flex space-x-6']); ?>
    <a class="text-right" href="<?php echo e(url('/listings/'.$listing->id .'/edit')); ?>"> <i class="fa-solid fa-pencil"></i></i> Edit</a>


    <form method="POST" action="<?php echo e(url('')); ?>/listings/<?php echo e($listing->id); ?>/delete">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button> <i class="fa-solid fa-trash"></i> Delete</button>
    </form>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8)): ?>
<?php $component = $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8; ?>
<?php unset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8); ?>
<?php endif; ?>






            </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\xampp\htdocs\laragigs\resources\views/listings/show.blade.php ENDPATH**/ ?>