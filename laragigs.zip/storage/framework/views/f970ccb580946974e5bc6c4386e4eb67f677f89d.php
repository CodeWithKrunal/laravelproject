<nav class="flex justify-between items-center mb-4">
    <a href="<?php echo e(url('/')); ?>">
        <img class="w-24" src="<?php echo url('public/images/logo.png') ?>" alt="" class="logo"/>
    </a>
    <ul class="flex space-x-6 mr-6 text-lg">
       <?php if(auth()->guard()->check()): ?>
        <li>
            <span class="font-bold uppercase">
                Welcome <?php echo e(auth()->user()->name); ?>

            </span>
        </li>
        <li>
            <a href="<?php echo e(url('')); ?>/listings/manage" class="hover:text-laravel">
                <i class="fa-solid fa-gear"></i>
                Manage Listing</a
            >
        </li>

        <li>
            <form method="post" action="<?php echo e(url('')); ?>/logout">
                <?php echo csrf_field(); ?>
                <button type="submit"><i class="fa-solid fa-door-closed"></i> LogOut</button>
            </form>
        </li>
       <?php else: ?>

        <li>
            <a href="<?php echo e(url('')); ?>/register" class="hover:text-laravel">
                <i class="fa-solid fa-user-plus"></i> Register</a>
        </li>
        <li>
            <a href="<?php echo e(url('')); ?>/login" class="hover:text-laravel">
                <i class="fa-solid fa-arrow-right-to-bracket"></i>
                Login</a
            >
        </li>
        <?php endif; ?>
    </ul>
</nav>
<?php /**PATH I:\xampp\htdocs\laragigs\resources\views/partials/_nav.blade.php ENDPATH**/ ?>