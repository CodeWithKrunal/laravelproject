<?php /* ?>
<h1><?php echo $heading; ?></h1>
<br/>
<?php foreach ($listings as $listing) { ?>
    <h2><?php echo  $listing['title']; ?></h2>
    <p><?php echo $listing['description']; ?></p>
<?php } ?>

<?php */ ?>
<?php /* ?>
<?php
$test = 1;
?>
{{$test}}


<h1>{{$heading}}</h1>
<br/>
<?php */ ?>





<?php $__env->startSection('content'); ?>

<div class="lg:grid lg:grid-cols-2 gap-4 space-y-4 md:space-y-0 mx-4">
<?php if (! (count($listings)  == 0)): ?>
<?php $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <?php /* ?>   <h2><a href="/laragigs/listings/{{$listing['id']}}">{{$listing['title']}}</a></h2>
    <p>{{$listing['description']}}</p> <?php */ ?>

 <!-- Item 1 -->



<?php if (isset($component)) { $__componentOriginal1c5b5ed90b8e7e3fc20c2153f073e6ed39da5342 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Listingcard::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('listingcard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Listingcard::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['listing' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($listing)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1c5b5ed90b8e7e3fc20c2153f073e6ed39da5342)): ?>
<?php $component = $__componentOriginal1c5b5ed90b8e7e3fc20c2153f073e6ed39da5342; ?>
<?php unset($__componentOriginal1c5b5ed90b8e7e3fc20c2153f073e6ed39da5342); ?>
<?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php else: ?>
<p>No Record Found.</p>
<?php endif; ?>

</div>
<div class="mt-6 p-4">
    <?php echo e($listings->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\xampp\htdocs\laragigs\resources\views/listings/index.blade.php ENDPATH**/ ?>